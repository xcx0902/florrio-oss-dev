import { createPetalHooks, functionIds as petalIds } from '../game/server/petals.mjs';
import { createEntityHooks, functionIds as entityIds } from '../game/server/entities.mjs';
import { createServerOutputHooks, functionIds as outputIds } from '../game/server/output.mjs';
import { createClientTransportHooks, functionIds as transportIds } from '../game/client/transport.mjs';
import { createSpecialPetalHooks, functionIds as specialPetalIds } from '../game/server/petals-special.mjs';
import { createCombatHooks, functionIds as combatIds } from '../game/server/combat.mjs';
import { createClientSnapshotHooks, functionIds as snapshotIds } from '../game/client/snapshots.mjs';
import { createPetalFactoryHooks, functionIds as petalFactoryIds } from '../game/server/petal-factories.mjs';
import { createTransformHooks, functionIds as transformIds } from '../game/server/transforms.mjs';
import { createDamageHooks, functionIds as damageIds } from '../game/server/damage.mjs';
import { createPetalLifecycleHooks, functionIds as petalLifecycleIds } from '../game/server/petal-lifecycle.mjs';
import { createSnapshotDecoderHooks, functionIds as snapshotDecoderIds } from '../game/client/snapshot-decoder.mjs';
import { createOwnershipHooks, functionIds as ownershipIds } from '../game/server/ownership.mjs';
import { createSpatialAiHooks, functionIds as spatialAiIds } from '../game/server/spatial-ai.mjs';
import { createEffectHooks, functionIds as effectIds } from '../game/server/effects.mjs';
import { createSimulationHooks, functionIds as simulationIds } from '../game/server/simulation.mjs';
import { createClockHooks, functionIds as clockIds } from '../game/server/clock.mjs';
import { createInitializationHooks, functionIds as initializationIds } from '../game/server/initialization.mjs';
import { createLoadoutHooks, functionIds as loadoutIds } from '../game/server/loadout.mjs';
import { createInputHooks, functionIds as inputIds } from '../game/server/input.mjs';
import { createEntitySnapshotHooks, functionIds as entitySnapshotIds } from '../game/client/entity-snapshot.mjs';
import { createComponentHooks, functionIds as componentIds } from '../game/server/components.mjs';
import { createSimulationTickHooks, functionIds as simulationTickIds } from '../game/server/simulation-tick.mjs';
import { createClientFrameHooks, functionIds as clientFrameIds } from '../game/client/frame.mjs';
import { createRenderFrameHooks, functionIds as renderFrameIds } from '../game/client/render-frame.mjs';
import { createClientClockHooks, functionIds as clientClockIds } from '../game/client/clock.mjs';
import { createClientTransformHooks, functionIds as clientTransformIds } from '../game/client/transforms.mjs';
import { createDrawingPrimitiveHooks, functionIds as drawingPrimitiveIds } from '../game/client/drawing-primitives.mjs';
import { createTextHooks, functionIds as textIds } from '../game/client/text.mjs';
import { createEntityRendererHooks, functionIds as entityRendererIds } from '../game/client/entity-renderer.mjs';
import { createClientRuntimePrimitiveHooks, functionIds as clientRuntimePrimitiveIds } from '../game/client/runtime-primitives.mjs';
import { createPlayerAppearanceHooks, functionIds as playerAppearanceIds } from '../game/client/player-appearance.mjs';
import { createComponent132RendererHooks, functionIds as component132RendererIds } from '../game/client/component-132-renderer.mjs';
import { createComponent148RendererHooks, functionIds as component148RendererIds } from '../game/client/component-148-renderer.mjs';
import { createClientMathHooks, functionIds as clientMathIds } from '../game/client/math.mjs';
import { createComponent128RendererHooks, functionIds as component128RendererIds } from '../game/client/component-128-renderer.mjs';
import { createComponents6480RendererHooks, functionIds as components6480RendererIds } from '../game/client/components-64-80-renderer.mjs';
import { createEyeRendererHooks, functionIds as eyeRendererIds } from '../game/client/eye-renderer.mjs';
import { createClientTrigHooks, functionIds as clientTrigIds } from '../game/client/trig.mjs';
import { createClientDoubleTrigHooks, functionIds as clientDoubleTrigIds } from '../game/client/double-trig.mjs';
import { createClientMemoryFillHooks, functionIds as clientMemoryFillIds } from '../game/client/memory-fill.mjs';
import { createEntityDefinitionHooks, functionIds as clientEntityDefinitionIds } from '../game/client/entity-definition.mjs';

const groups = {
  sp_server: [
    { source: 'game/server/petals.mjs', ids: petalIds, factory: createPetalHooks },
    { source: 'game/server/entities.mjs', ids: entityIds, factory: createEntityHooks },
    { source: 'game/server/output.mjs', ids: outputIds, factory: createServerOutputHooks },
    { source: 'game/server/petals-special.mjs', ids: specialPetalIds, factory: createSpecialPetalHooks },
    { source: 'game/server/combat.mjs', ids: combatIds, factory: createCombatHooks },
    { source: 'game/server/petal-factories.mjs', ids: petalFactoryIds, factory: createPetalFactoryHooks },
    { source: 'game/server/transforms.mjs', ids: transformIds, factory: createTransformHooks },
    { source: 'game/server/damage.mjs', ids: damageIds, factory: createDamageHooks },
    { source: 'game/server/petal-lifecycle.mjs', ids: petalLifecycleIds, factory: createPetalLifecycleHooks },
    { source: 'game/server/ownership.mjs', ids: ownershipIds, factory: createOwnershipHooks },
    { source: 'game/server/spatial-ai.mjs', ids: spatialAiIds, factory: createSpatialAiHooks },
    { source: 'game/server/effects.mjs', ids: effectIds, factory: createEffectHooks },
    { source: 'game/server/simulation.mjs', ids: simulationIds, factory: createSimulationHooks },
    { source: 'game/server/clock.mjs', ids: clockIds, factory: createClockHooks },
    { source: 'game/server/initialization.mjs', ids: initializationIds, factory: createInitializationHooks },
    { source: 'game/server/loadout.mjs', ids: loadoutIds, factory: createLoadoutHooks },
    { source: 'game/server/input.mjs', ids: inputIds, factory: createInputHooks },
    { source: 'game/server/components.mjs', ids: componentIds, factory: createComponentHooks },
    { source: 'game/server/simulation-tick.mjs', ids: simulationTickIds, factory: createSimulationTickHooks },
  ],
  client: [
    { source: 'game/client/transport.mjs', ids: transportIds, factory: createClientTransportHooks },
    { source: 'game/client/snapshots.mjs', ids: snapshotIds, factory: createClientSnapshotHooks },
    { source: 'game/client/snapshot-decoder.mjs', ids: snapshotDecoderIds, factory: createSnapshotDecoderHooks },
    { source: 'game/client/entity-snapshot.mjs', ids: entitySnapshotIds, factory: createEntitySnapshotHooks },
    { source: 'game/client/frame.mjs', ids: clientFrameIds, factory: createClientFrameHooks },
    { source: 'game/client/render-frame.mjs', ids: renderFrameIds, factory: createRenderFrameHooks },
    { source: 'game/client/clock.mjs', ids: clientClockIds, factory: createClientClockHooks },
    { source: 'game/client/transforms.mjs', ids: clientTransformIds, factory: createClientTransformHooks },
    { source: 'game/client/drawing-primitives.mjs', ids: drawingPrimitiveIds, factory: createDrawingPrimitiveHooks },
    { source: 'game/client/text.mjs', ids: textIds, factory: createTextHooks },
    { source: 'game/client/entity-renderer.mjs', ids: entityRendererIds, factory: createEntityRendererHooks },
    { source: 'game/client/runtime-primitives.mjs', ids: clientRuntimePrimitiveIds, factory: createClientRuntimePrimitiveHooks },
    { source: 'game/client/player-appearance.mjs', ids: playerAppearanceIds, factory: createPlayerAppearanceHooks },
    { source: 'game/client/component-132-renderer.mjs', ids: component132RendererIds, factory: createComponent132RendererHooks },
    { source: 'game/client/component-148-renderer.mjs', ids: component148RendererIds, factory: createComponent148RendererHooks },
    { source: 'game/client/math.mjs', ids: clientMathIds, factory: createClientMathHooks },
    { source: 'game/client/component-128-renderer.mjs', ids: component128RendererIds, factory: createComponent128RendererHooks },
    { source: 'game/client/components-64-80-renderer.mjs', ids: components6480RendererIds, factory: createComponents6480RendererHooks },
    { source: 'game/client/eye-renderer.mjs', ids: eyeRendererIds, factory: createEyeRendererHooks },
    { source: 'game/client/trig.mjs', ids: clientTrigIds, factory: createClientTrigHooks },
    { source: 'game/client/double-trig.mjs', ids: clientDoubleTrigIds, factory: createClientDoubleTrigHooks },
    { source: 'game/client/memory-fill.mjs', ids: clientMemoryFillIds, factory: createClientMemoryFillHooks },
    { source: 'game/client/entity-definition.mjs', ids: clientEntityDefinitionIds, factory: createEntityDefinitionHooks },
  ],
};

export function recoveredFunctionPlan(moduleName) {
  const entries = groups[moduleName].flatMap(group => group.ids.map(id => ({ id, source: group.source })));
  if (new Set(entries.map(entry => entry.id)).size !== entries.length) throw new Error(`Duplicate recovered function in ${moduleName}`);
  return entries;
}
export function createRecoveredFunctions(moduleName, runtime) {
  const functions = {};
  for (const group of groups[moduleName]) {
    const hooks = group.factory(runtime);
    if (Object.keys(hooks).length !== group.ids.length) throw new Error(`Hook manifest disagrees with ${group.source}`);
    for (const id of group.ids) {
      if (typeof hooks[id] !== 'function') throw new Error(`Missing implementation for ${moduleName} function ${id}`);
      functions[id] = hooks[id];
    }
  }
  return functions;
}
