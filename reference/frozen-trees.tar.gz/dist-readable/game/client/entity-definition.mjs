/**
 * Complete original client entity-definition functions 391 and 441.
 *
 * 441 writes one 116-byte catalog record. 391 is the one-time initializer for
 * the whole catalog: type 0 is the "None" record, types 1..22 are the shipped
 * entities, and the returned pointer is 384096 + 116 * type for those types.
 *
 * The catalog table below is the original initialized state. Name and
 * description fields retain the original C-string pointers because the game
 * reads those strings directly; the adjacent comments are the bytes at those
 * pointers. The entry values are the original eight-byte drops vector values.
 */
export const functionIds = Object.freeze([391, 441]);

const CATALOG_BASE = 384096;
const CATALOG_STRIDE = 116;
const INITIALIZATION_GUARD = 386764;
const INITIALIZATION_FRAME_SIZE = 2192;

/** @type {ReadonlyArray<{namePointer:number,name:string,descriptions:Array<[number,string]>,shape:number,scale:number,entries:bigint[],callbacks:[number,number],flags:number,marker:number,tailScale:number,rawTail?:bigint}>} */
const entityDefinitions = Object.freeze([
  {
    namePointer: 16292, name: 'None',
    descriptions: [[23393, '???']],
    shape: 0, scale: 0, entries: [], callbacks: [0, 0],
    flags: 1, marker: 0, tailScale: 1,
  },
  {
    namePointer: 14105, name: 'Rock',
    descriptions: [[27163, "A rock. It doesn't do much."]],
    shape: 0, scale: 1, entries: [2n, 3n, 4n], callbacks: [192, 193],
    flags: 1, marker: 0, tailScale: 1,
  },
  {
    namePointer: 12654, name: 'Boulder',
    descriptions: [[26687, "A bigger rock. It doesn't do much either."]],
    shape: 1, scale: 10, entries: [3n, 4n, 26n], callbacks: [194, 195],
    flags: 1, marker: 0, tailScale: 1,
  },
  {
    namePointer: 9630, name: 'Cactus',
    descriptions: [[26038, 'Avoid touching it, it hurts.']],
    shape: 0, scale: 2, entries: [7n, 10n, 13n, 21n, 33n], callbacks: [196, 197],
    flags: 1, marker: 0, tailScale: 1,
  },
  {
    namePointer: 15092, name: 'Ladybug',
    descriptions: [[26231, 'Cute and harmless.']],
    shape: 0, scale: 3, entries: [2n, 6n, 16n, 9n, 18n], callbacks: [198, 199],
    flags: 1, marker: 0, tailScale: 1,
  },
  {
    namePointer: 15084, name: 'Massive Ladybug',
    descriptions: [[27457, 'This one is really big, but still cute.']],
    shape: 3, scale: 50, entries: [6n, 18n, 24n, 15n], callbacks: [201, 200],
    flags: 1, marker: 0, tailScale: 10, rawTail: 0x4120000000000001n,
  },
  {
    namePointer: 16961, name: 'Bee',
    descriptions: [[25805, "It stings. Don't touch it."]],
    shape: 0, scale: 3, entries: [2n, 7n, 16n, 9n, 18n, 31n], callbacks: [202, 203],
    flags: 1, marker: 0, tailScale: 1,
  },
  {
    namePointer: 8384, name: 'Baby Ant',
    descriptions: [[26289, 'Weak and defenseless, but big dreams.']],
    shape: 0, scale: 1, entries: [2n, 32n, 16n, 17n, 37n], callbacks: [204, 205],
    flags: 1, marker: 0, tailScale: 1,
  },
  {
    namePointer: 8393, name: 'Worker Ant',
    descriptions: [[27752, "It's a bit temperamental, probably from working all the time."]],
    shape: 0, scale: 2, entries: [2n, 32n, 16n, 17n, 38n], callbacks: [206, 207],
    flags: 1, marker: 0, tailScale: 1,
  },
  {
    namePointer: 8404, name: 'Soldier Ant',
    descriptions: [[26957, "It's got wings and it's ready to use them."]],
    shape: 1, scale: 5, entries: [16n, 8n, 9n, 14n, 17n], callbacks: [208, 209],
    flags: 1, marker: 0, tailScale: 1,
  },
  {
    namePointer: 8416, name: 'Queen Ant',
    descriptions: [[25375, "You must have done something really bad if she's chasing you."]],
    shape: 2, scale: 20, entries: [16n, 9n, 14n, 17n, 22n, 27n], callbacks: [210, 211],
    flags: 1, marker: 0, tailScale: 1,
  },
  {
    namePointer: 16453, name: 'Ant Hole',
    descriptions: [[25832, "Ants go in, and come out. Can't explain that."]],
    shape: 2, scale: 20, entries: [8n, 9n, 22n], callbacks: [212, 213],
    flags: 1, marker: 0, tailScale: 1,
  },
  {
    namePointer: 16413, name: 'Beetle',
    descriptions: [[27036, "It's hungry and flowers are its favorite meal."]],
    shape: 1, scale: 5, entries: [8n, 9n, 36n, 17n], callbacks: [214, 215],
    flags: 1, marker: 0, tailScale: 1,
  },
  {
    namePointer: 16405, name: 'Massive Beetle',
    descriptions: [[25437, 'Someone overfed this one, you might be next.']],
    shape: 2, scale: 50, entries: [8n, 9n, 17n, 23n], callbacks: [216, 217],
    flags: 1, marker: 0, tailScale: 1,
  },
  {
    namePointer: 8704, name: 'Hornet',
    descriptions: [[26414, "These aren't quite as nice as the little bees."]],
    shape: 1, scale: 10, entries: [10n, 9n, 31n, 18n, 20n, 25n], callbacks: [219, 218],
    flags: 1, marker: 0, tailScale: 2, rawTail: 0x4000000000000001n,
  },
  {
    namePointer: 17025, name: 'Centipede',
    descriptions: [[27191, "It's just there doing its thing."]],
    shape: 1, scale: 3, entries: [2n, 32n, 16n, 11n, 12n, 17n], callbacks: [220, 221],
    flags: 1, marker: 0, tailScale: 1,
  },
  {
    // The original writes this variant through its 116-byte record copy path,
    // which leaves flags 0x0f00 and marker 0x0f instead of the normal 1/0.
    namePointer: 17025, name: 'Centipede',
    descriptions: [[27191, "It's just there doing its thing."]],
    shape: 1, scale: 3, entries: [], callbacks: [222, 0],
    flags: 0x0f00, marker: 0x0f, tailScale: 1, rawTail: 0x3f800000000f0f00n,
  },
  {
    namePointer: 17020, name: 'Evil Centipede',
    descriptions: [[26250, 'This one loves flowers.']],
    shape: 2, scale: 5, entries: [8n, 12n, 34n, 17n], callbacks: [223, 224],
    flags: 1, marker: 0, tailScale: 1,
  },
  {
    // As with type 16, the record copy path preserves 0x1100/0x11 here.
    namePointer: 17020, name: 'Evil Centipede',
    descriptions: [[26250, 'This one loves flowers.']],
    shape: 2, scale: 5, entries: [], callbacks: [225, 0],
    flags: 0x1100, marker: 0x11, tailScale: 1, rawTail: 0x3f80000000111100n,
  },
  {
    namePointer: 16241, name: 'Square',
    descriptions: [[28551, 'This shape... it looks familiar...']],
    shape: 5, scale: 10, entries: [5n], callbacks: [226, 227],
    flags: 1, marker: 0, tailScale: 1,
  },
  {
    namePointer: 15092, name: 'Ladybug',
    descriptions: [[28347, 'Cute and harmless... if left unprovoked.']],
    shape: 1, scale: 5, entries: [15n, 24n, 9n, 18n, 17n, 28n], callbacks: [228, 229],
    flags: 1, marker: 0, tailScale: 1,
  },
  {
    namePointer: 15092, name: 'Ladybug',
    descriptions: [[26198, 'Shiny, cute and mostly harmless.']],
    shape: 1, scale: 5, entries: [6n, 24n, 16n, 9n, 18n, 17n], callbacks: [231, 230],
    flags: 1, marker: 0, tailScale: 1 / 5, rawTail: 0x3e4ccccd00000001n,
  },
  {
    namePointer: 12662, name: 'Spider',
    descriptions: [[25272, 'Spooky.']],
    shape: 1, scale: 5, entries: [8n, 7n, 14n, 29n, 30n], callbacks: [232, 233],
    flags: 1, marker: 0, tailScale: 1,
  },
].map(spec => Object.freeze(spec)));

export function createEntityDefinitionHooks(runtime) {
  let buffer, view;
  function refresh() {
    if (buffer !== runtime.memory.buffer) {
      buffer = runtime.memory.buffer;
      view = new DataView(buffer);
    }
  }
  function location(base, size, offset = 0) {
    refresh();
    const address = (base + offset) >>> 0;
    if (address + size > view.byteLength)
      throw new WebAssembly.RuntimeError('memory access out of bounds');
    return address;
  }
  function readU8(base) { const at = location(base, 1); return view.getUint8(at); }
  function readU16(base) { const at = location(base, 2); return view.getUint16(at, true); }
  function readU32(base) { const at = location(base, 4); return view.getUint32(at, true); }
  function readU64(base) { const at = location(base, 8); return view.getBigUint64(at, true); }
  function writeU8(base, value) { const at = location(base, 1); view.setUint8(at, value); }
  function writeU16(base, value) { const at = location(base, 2); view.setUint16(at, value, true); }
  function writeU32(base, value) { const at = location(base, 4); view.setUint32(at, value, true); }
  function writeU64(base, value) { const at = location(base, 8); view.setBigUint64(at, value, true); }
  function writeF32(base, value) {
    const at = location(base, 4), number = Number(value);
    // The wasm f32 boundary canonicalizes NaN, including ToNumber(undefined).
    view.setFloat32(at, Number.isNaN(number) ? NaN : number, true);
  }

  /** Original441: write one entity catalog record, preserving copy and trap order. */
  function initializeEntityDefinition(destination, name, descriptions, shape, scale, entries, firstCallback, secondCallback) {
    let p0 = destination >>> 0;
    writeU32(p0, name);
    const description = readU64(descriptions >>> 0);
    const descriptionCount = Number(description >> 32n) >>> 0;
    writeU8((p0 + 4) >>> 0, descriptionCount & 255);
    let source = Number(description & 0xffffffffn) >>> 0;
    let target = (p0 + 8) >>> 0;
    for (let index = 0; index < descriptionCount; index++) {
      writeU32(target, readU32(source));
      source = (source + 4) >>> 0;
      target = (target + 4) >>> 0;
    }

    p0 = destination >>> 0;
    writeU8((p0 + 32) >>> 0, 0);
    writeF32((p0 + 28) >>> 0, scale);
    writeU32((p0 + 24) >>> 0, shape);

    const p5 = entries >>> 0;
    const entryCount = readU8(p5);
    source = (p5 + 4) >>> 0;
    target = (p0 + 36) >>> 0;
    for (let index = 0; index < entryCount; index++) {
      writeU64(target, readU64(source));
      source = (source + 8) >>> 0;
      target = (target + 8) >>> 0;
    }

    p0 = destination >>> 0;
    writeF32((p0 + 112) >>> 0, 1);
    writeU8((p0 + 110) >>> 0, 0);
    writeU16((p0 + 108) >>> 0, 1);
    writeU32((p0 + 104) >>> 0, secondCallback);
    writeU32((p0 + 100) >>> 0, firstCallback);
    writeU8((p0 + 32) >>> 0, readU8(p5));
  }

  /** Write the exact fields present in one initialized catalog record. */
  function writeDefinition(destination, definition) {
    const p0 = destination >>> 0;
    writeU32(p0, definition.namePointer);
    writeU8((p0 + 4) >>> 0, definition.descriptions.length);
    for (let index = 0; index < definition.descriptions.length; index++)
      writeU32((p0 + 8 + index * 4) >>> 0, definition.descriptions[index][0]);
    writeU32((p0 + 24) >>> 0, definition.shape);
    writeF32((p0 + 28) >>> 0, definition.scale);
    writeU8((p0 + 32) >>> 0, definition.entries.length);
    for (let index = 0; index < definition.entries.length; index++)
      writeU64((p0 + 36 + index * 8) >>> 0, definition.entries[index]);
    writeU32((p0 + 100) >>> 0, definition.callbacks[0]);
    writeU32((p0 + 104) >>> 0, definition.callbacks[1]);
    if (definition.rawTail !== undefined) {
      // The 116-byte record copy path overwrites the complete tail, including
      // byte 111, which the ordinary 441 field stores leave untouched.
      writeU64((p0 + 108) >>> 0, definition.rawTail);
    } else {
      writeU16((p0 + 108) >>> 0, definition.flags);
      writeU8((p0 + 110) >>> 0, definition.marker);
      writeF32((p0 + 112) >>> 0, definition.tailScale);
    }
  }

  /** Original 369 state machine used by the catalog's one-time guard. */
  function acquireStaticInitializationGuard(address) {
    const saved = runtime.stackPointer.value;
    // 369 allocates one 16-byte frame and its inner atomic helper another.
    runtime.stackPointer.value = (saved - 32) >>> 0;
    let acquired = 0;
    if (readU8(address) === 0) {
      const state = readU8((address + 1) >>> 0);
      if (state === 1) {
        acquired = 0;
      } else if ((state & 2) !== 0) {
        // Native `unreachable`; both frames remain allocated on a trap.
        throw new WebAssembly.RuntimeError('unreachable');
      } else {
        writeU8((address + 1) >>> 0, 2);
        acquired = 1;
      }
    }
    runtime.stackPointer.value = saved;
    return acquired;
  }

  /** Original370 commits the one-time initialization guard. */
  function releaseStaticInitializationGuard(address) {
    writeU8(address, 1);
    writeU8((address + 1) >>> 0, 1);
  }

  /** Original391: lazily initialize the catalog, then look up one entity type. */
  function getEntityDefinition(type) {
    const rawType = type >>> 0;
    const entryStack = runtime.stackPointer.value;
    runtime.stackPointer.value = (entryStack - INITIALIZATION_FRAME_SIZE) >>> 0;
    if ((readU8(INITIALIZATION_GUARD) & 1) === 0 &&
        acquireStaticInitializationGuard(INITIALIZATION_GUARD)) {
      for (let index = 0; index < entityDefinitions.length; index++)
        writeDefinition(CATALOG_BASE + index * CATALOG_STRIDE, entityDefinitions[index]);
      releaseStaticInitializationGuard(INITIALIZATION_GUARD);
    }
    runtime.stackPointer.value = entryStack;

    const index = (rawType - 1) >>> 0;
    if ((index & 255) > 21) return 0;
    return (CATALOG_BASE + Math.imul(rawType, CATALOG_STRIDE)) >>> 0;
  }

  return Object.freeze({391: getEntityDefinition, 441: initializeEntityDefinition});
}
